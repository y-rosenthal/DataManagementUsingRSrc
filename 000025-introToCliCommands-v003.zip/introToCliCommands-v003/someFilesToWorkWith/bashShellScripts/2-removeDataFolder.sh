echo "
Due to the dangerous nature of these commands, we will not run them. 
Rather, we will just descirbe them.

# The rm command will removes files --- there is NO WAY TO GET THESE FILES BACK
#
# The rmdir command removes empty directories
#
# WARNING!!! BE VERY CAREFUL WITH THE FOLLOWING COMMAND
# DON'T RUN rm -r UNLESS YOU ARE 100% SURE YOU KNOW WHAT YOU'RE DOING
# THe rm -r command removes an entire folder hierarchy. There is no way to get these files back.
"
