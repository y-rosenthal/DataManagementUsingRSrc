#create a new directory called "data"
mkdir data

#navigate into the "data" directory
cd data

#create a new subdirectory called "customers"
mkdir customers

#navigate into the "customers" directory
cd customers

#create a new text file called "john_doe_info.txt" with some data and save it in the current directory
echo "Name: John Doe
Address: 123 Main St, Anytown USA
Phone: 555-555-5555
Email: john.doe@email.com" > john_doe_info.txt

#create another new text file called "jane_smith_info.txt" with some data and save it in the current directory
echo "Name: Jane Smith
Address: 456 Park Ave, Anytown USA
Phone: 555-555-5556
Email: jane.smith@email.com" > jane_smith_info.txt

# create a csv file with customer information 
echo "Name,Address,Phone,Email" > customers.csv
echo "John Doe,123 Main St, Anytown USA,555-555-5555,john.doe@email.com" >> customers.csv
echo "Jane Smith,456 Park Ave, Anytown USA,555-555-5556,jane.smith@email.com" >> customers.csv

#go back to the parent directory
cd ..

#create another new subdirectory called "employees"
mkdir employees

#navigate into the "employees" directory
cd employees

#create a new text file called "mike_johnson_info.txt" with some data and save it in the current directory
echo "Name: Mike Johnson
Position: Manager
Address: 789 Elm St, Anytown USA
Phone: 555-555-5557
Email: mike.johnson@email.com" > mike_johnson_info.txt

#create another new text file called "sara_lee_info.txt" with some data and save it in the current directory
echo "Name: Sara Lee
Position: Assistant
Address: 321 Oak St, Anytown USA
Phone: 555-555-5558
Email: sara.lee@email.com" > sara_lee_info.txt

# create a csv file with employee information 
echo "Name,Position,Address,Phone,Email" > employees.csv
echo "Mike Johnson,Manager,789 Elm St, Anytown USA,555-555-5557,mike.johnson@email.com" >> employees.csv
echo "Sara Lee,Assistant,321 Oak St, Anytown USA,555-555-5558,sara.lee@email.com" >> employees.csv

#go back to the parent directory
cd ..

#see the tree structure of the files and directories
echo "
data folder was created.

On many sysems (e.g. Mac) you can use the tree command to see the full
structure of this folder. Just run the command 'tree data' (without the 'quotes').
"
