echo this script displays the values of the command line arguments

echo the name of this script is $0

echo the first value on the command line after the name of the script was $1
echo the second value on the command line after the name of the script was $2
echo the third value on the command line after the name of the script was $3
echo the fourth value on the command line after the name of the script was $4

