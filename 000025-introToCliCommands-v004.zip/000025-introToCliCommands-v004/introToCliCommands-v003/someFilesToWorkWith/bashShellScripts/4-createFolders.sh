# Call this script in the following way:
#
#     createFolders <parentFolderName>
#
# This will create a folder with the parentFolderName 
# and several other folders inside of the parent folder

echo creating the folders in $1 ...

mkdir $1

mkdir $1/questions
mkdir $1/answers
mkdir $1/notes

echo This folder was created on > $1/readme.txt
date >> $1/readme.txt  # append the output of the date command to the readme.txt file

